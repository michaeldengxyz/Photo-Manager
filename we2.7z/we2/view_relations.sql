-- --------------------------------------------------------
-- 主机:                           127.0.0.1
-- 服务器版本:                        8.0.21 - MySQL Community Server - GPL
-- 服务器操作系统:                      Win64
-- HeidiSQL 版本:                  11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- 导出  视图 we2.view_relations 结构
-- 移除临时表并创建最终视图结构
DROP TABLE IF EXISTS `view_relations`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `view_relations` AS select `faces`.`id` AS `id`,`faces`.`file_id` AS `file_id`,`filelist`.`dir_id` AS `dir_id`,`faces`.`fixed` AS `fixed`,`faces`.`label` AS `label`,`filelist`.`name` AS `filename`,`faces`.`path` AS `face_path`,if(((`faces`.`label_correct` is not null) and (`faces`.`label_correct` <> '')),`faces`.`label_correct`,'') AS `name`,if((`filelist`.`exif_gpsinfo` is not null),`filelist`.`exif_gpsinfo`,'') AS `gpsinfo`,`filelist`.`exif_model` AS `model`,`filelist`.`exif_make` AS `exif_make`,`dirlist`.`path` AS `path` from ((`faces` join `filelist`) join `dirlist`) where ((`faces`.`file_id` = `filelist`.`id`) and (`filelist`.`type` = 'image') and (`dirlist`.`id` = `filelist`.`dir_id`) and (`faces`.`is_repeated` = 0));

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
