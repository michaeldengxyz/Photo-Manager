-- --------------------------------------------------------
-- 主机:                           127.0.0.1
-- 服务器版本:                        8.0.21 - MySQL Community Server - GPL
-- 服务器操作系统:                      Win64
-- HeidiSQL 版本:                  11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- 导出  视图 we2.view_repeated 结构
-- 移除临时表并创建最终视图结构
DROP TABLE IF EXISTS `view_repeated`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `view_repeated` AS select `filelist`.`id` AS `id`,`filelist`.`md5` AS `md5`,`filelist`.`size` AS `size`,`filelist`.`name` AS `name`,`dirlist`.`path` AS `path` from (`filelist` join `dirlist`) where ((`dirlist`.`id` = `filelist`.`dir_id`) and (`filelist`.`type` = 'image')) order by `filelist`.`md5`,`filelist`.`size`,`filelist`.`name`;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
