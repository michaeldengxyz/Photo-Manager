-- --------------------------------------------------------
-- 主机:                           127.0.0.1
-- 服务器版本:                        8.0.21 - MySQL Community Server - GPL
-- 服务器操作系统:                      Win64
-- HeidiSQL 版本:                  11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- 导出  视图 we2.view_face_no_name 结构
-- 移除临时表并创建最终视图结构
DROP TABLE IF EXISTS `view_face_no_name`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `view_face_no_name` AS select `faces`.`id` AS `id`,`faces`.`fixed` AS `fixed`,`faces`.`label_correct` AS `label_correct`,`faces`.`path` AS `path`,`faces`.`file_id` AS `idx`,`faces`.`label` AS `label`,`filelist`.`name` AS `filename`,if(((`faces`.`image_face_looking_bias` = -(1)) or (`faces`.`image_face_looking_bias` is null)),'--',`faces`.`image_face_looking_bias`) AS `looking`,if(((`faces`.`image_laplacian` is null) or (`faces`.`image_laplacian` = 0)),'--',`faces`.`image_laplacian`) AS `laplacian`,if((`faces`.`image_brightness` is null),0,`faces`.`image_brightness`) AS `brightness`,if(((`faces`.`image_slope_nose_bridge` is not null) and (`faces`.`image_slope_nose_bridge` > 0)),round(((abs((`faces`.`image_bias_eyes` * 100)) + abs((`faces`.`image_slope_eyes` * 1000))) / abs(`faces`.`image_slope_nose_bridge`)),0),'--') AS `status` from (`faces` join `filelist`) where ((`filelist`.`id` = `faces`.`file_id`) and (`faces`.`invisible` = 0) and ((`faces`.`label_correct` is null) or (`faces`.`label_correct` = '')) and (`faces`.`is_repeated` = 0));

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
