-- --------------------------------------------------------
-- 主机:                           127.0.0.1
-- 服务器版本:                        8.0.21 - MySQL Community Server - GPL
-- 服务器操作系统:                      Win64
-- HeidiSQL 版本:                  11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- 导出  表 we2.faces 结构
CREATE TABLE IF NOT EXISTS `faces` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invisible` int DEFAULT '0',
  `fixed` int DEFAULT '0',
  `file_id` int DEFAULT NULL,
  `is_repeated` int NOT NULL DEFAULT '0',
  `label` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label_correct` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tf_accurate` float DEFAULT NULL,
  `path` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `idx` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dir_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_id` int DEFAULT NULL,
  `image_face_side` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `image_bias_eyes` float DEFAULT NULL,
  `image_slope_eyes` float DEFAULT NULL,
  `image_slope_nose_bridge` float DEFAULT NULL,
  `image_face_looking_bias` float DEFAULT NULL,
  `image_laplacian` float DEFAULT NULL,
  `image_brightness` float DEFAULT NULL,
  `image_overall_evaluation` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `image_id` (`image_id`),
  KEY `id` (`id`),
  KEY `file_id` (`file_id`),
  KEY `label` (`label`),
  KEY `label_correct` (`label_correct`),
  KEY `label_2` (`label`),
  KEY `idx` (`idx`),
  KEY `dir_id` (`dir_id`),
  KEY `image_id_2` (`image_id`)
) ENGINE=InnoDB AUTO_INCREMENT=106354 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;

-- 数据导出被取消选择。

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
